﻿using UnityEngine;
using System.Collections;

public class EletroFSM : MonoBehaviour {

    public float DashSpeed;
    public float TimeDash;
    private float _timeDash;
    public GameObject Shadow;

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}

    public void JumpableUpdate()
    {
        if (InputController.Jump)
        {
            gameObject.Send<IPlayer>(_ => _.Jump()).Run();
        }
    }

    public void SkillableUpdate()
    {
        if (InputController.Skill)
        {
            gameObject.Send<IPlayer>(_ => _.Skill()).Run();
        }
    }

    public void DashEnter()
    {
        gameObject.Send<IPlayer>(_=>_.StartSkill()).Run();
        GetComponent<Animator>().SetBool("Dashing", true);
        _timeDash = TimeDash;
    }

    public void DashUpdate()
    {
        GameController.Spawn(Shadow, gameObject.transform.position);

        if (InputController.Jump)
        {
            GetComponent<Animator>().SetBool("Dashing", false);
            gameObject.Send<IPlayer>(_=>_.Jump()).Run();
        }

        var pos = gameObject.transform.position;
        var lookRight = gameObject.Request<IPlayer, int>(_ => _.IsLookRight());

        if (lookRight == 2)
        {
            if (gameObject.Request<IPlayer, int>(_ => _.IsFree(DashSpeed, true)) == 2)
            {
                pos.x += DashSpeed * Time.deltaTime;
            }
            else
            {
                GetComponent<Animator>().SetBool("Dashing", false);
            }
        }
        else
        {
            if (gameObject.Request<IPlayer, int>(_ => _.IsFree(DashSpeed, false)) == 2)
            {
                pos.x -= DashSpeed * Time.deltaTime;
            }
            else
            {
                GetComponent<Animator>().SetBool("Dashing", false);
            }
        }

        gameObject.transform.position = pos;

        _timeDash -= Time.deltaTime;
        if (_timeDash <= 0)
        {
            GetComponent<Animator>().SetBool("Dashing", false);
        }
    }

    public void DashExit()
    {
        gameObject.Send<IPlayer>(_=>_.EndSkill()).Run();
    }
}
